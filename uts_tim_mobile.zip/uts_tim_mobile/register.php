<?php

header("Access-Control-Allow-Origin: header");
header("Access-Control-Allow-Origin: *");
include 'koneksi.php';

if($_SERVER['REQUEST_METHOD'] == "POST") {

    $response = array();
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = md5($_POST['password']); 


    $cek = "SELECT * FROM tb_user WHERE email = '$email'"; 
    $result = mysqli_query($koneksi, $cek);

    if(mysqli_num_rows($result) > 0){ 
        $response['value'] = 2;
        $response['message'] = "Email telah digunakan";
        echo json_encode($response);
    } else {
        $insert = "INSERT INTO tb_user (fullname,  email, password, created) 
                   VALUES ('$fullname', '$email', '$password', NOW())";
        
        if(mysqli_query($koneksi, $insert)){
            $response['value'] = 1;
			$response['fullname'] = $fullname;
            $response['email'] = $email;

            $response['message'] = "Registrasi Berhasil";
            echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Gagal Registrasi";
            echo json_encode($response);
        }
    }
}

?>
