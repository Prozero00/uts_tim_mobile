<?php

header("Access-Control-Allow-Origin: *");
include 'koneksi.php';

if($_SERVER['REQUEST_METHOD'] == "POST") {
    $response = array();
    
    $id_sejarawan = $_POST['id_sejarawan'];
    $nama = $_POST['nama'];
    $foto = $_POST['foto']; 
    $tgl_lahir = $_POST['tgl_lahir']; 
    $asal = $_POST['asal'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $deskripsi = $_POST['deskripsi'] ;

    // Decode base64 string menjadi gambar
    $foto = base64_decode($foto);

    // Tentukan lokasi penyimpanan gambar
    $upload_path = "../uts_tim_mobile/image/"; // Ubah sesuai dengan lokasi penyimpanan Anda

    // Buat nama file unik
    $file_name = uniqid() . '.jpg'; // Ubah ekstensi sesuai dengan format gambar yang Anda terima

    // Simpan gambar di server
    if (file_put_contents($upload_path . $file_name, $foto)) {
    $sql = "UPDATE tb_sejarawan SET nama = '$nama', foto = '$file_name', tgl_lahir = '$tgl_lahir',asal = '$asal', jenis_kelamin = '$jenis_kelamin', deskripsi = '$deskripsi' WHERE id_sejarawan = $id_sejarawan";
    $isSuccess = $koneksi->query($sql);

    if ($isSuccess) {
        $cek = "SELECT * FROM tb_sejarawan WHERE id_sejarawan = $id_sejarawan";
        $result = mysqli_fetch_array(mysqli_query($koneksi, $cek));
        $response['is_success'] = true;
        $response['value'] = 1;
        $response['message'] = "Sejarawan Berhasil di Edit";
        $response['nama'] = $result['nama'];
        $response['foto'] = $result['foto'];
        $response['tgl_lahir'] = $result['tgl_lahir'];
        $response['asal'] = $result['asal'];
        $response['jenis_kelamin'] = $result['jenis_kelamin']; 
        $response['deskripsi'] = $result['deskripsi']; 
        $response['id_sejarawan'] = $result['id_sejarawan'];
    } else {
        $response['is_success'] = false;
        $response['value'] = 0;
        $response['message'] = "Gagal Edit User";
    }

    echo json_encode($response);
}
}

?>
