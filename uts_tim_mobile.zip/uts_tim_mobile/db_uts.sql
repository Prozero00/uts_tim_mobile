-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2024 at 07:30 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_uts`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_berita`
--

CREATE TABLE `tb_berita` (
  `id_berita` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `konten` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `author` text NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_berita`
--

INSERT INTO `tb_berita` (`id_berita`, `judul`, `konten`, `gambar`, `author`, `created`, `updated`) VALUES
(1, 'Ini batas waktu Perusahaan jasa konstruksi daftarkan pekerjanya BPJamsostek', 'Solok, (Minangkabaunews) – Setiap pemberi kerja jasa konstruksi wajib mendaftarkan pekerjanya dalam program Jaminan Kecelakaan kerja (JKK) dan Jaminan Kematian (JKM) BPJamsostek Sesuai dengan Amanat Permenaker Nomor 5 Tahun 2021 Pasal 66 Ayat 1.\n\nKepala Kantor BPJS Ketenagakerjaan Cabang Solok, Dr Maulana Anshari Siregar, di Solok, Rabu, mengatakan seluruh Perusahaan penyedia jasa konstruksi untuk memastikan bahwa semua proyek sudah WAJIB didaftarkan setelah 14 hari setelah SPK diterbitkan.\n\n“BPJS Ketenagakerjaan tidak menerima pendaftaran jika proyek sudah selesai dilaksanakan baru mendaftarkan pekerjanya karena tidak sesuai dengan regulasi yang ada,” katanya.\n\nSesuai dengan Surat Edaran Menteri PUPR Republik Indonesia Nomor 04/SE/M/2022 PPK dapat memastikan kepatuhan penyedia jasa konstruksi dalam pelaksanaan program jaminan sosial Ketenagakerjaan dengan cara PPK memeriksa sertifikat kepesertaan, nomor kepesertaan, dan bukti pembayaran iuran, serta daftar tenaga kerja konstruksi sebagai bukti kepesertaan Penyedia Jasa dalam Program Jaminan Sosial Ketenagakerjaan yang diserahkan Penyedia Jasa saat rapat persiapan pelaksanaan kontrak.\n\nArtinya tidak ada lagi proyek pemerintah daerah baik yang bersumber dari APBN/APBD/APBDes yang tidak memiliki perlindungan Jaminan Sosial Ketenagakerjaan.\n\nUntuk mendaftarkan proyek jasa konstruksi sangat mudah dengan datang di kantor Cabang terdekat atau melalui aplikasi E-Jakon.', 'berita10.jpg', 'Rizki Syaputra', '2024-03-11 06:20:15', NULL),
(2, 'Arab Saudi Tetapkan 1 Ramadan Jatuh pada Senin 11 Maret 2024', 'Jakarta - Arab Saudi menetapkan 1 Ramadan 1445 H jatuh pada hari Senin 11 Maret 2024. Penetapan 1 Ramadan di Arab Saudi setelah penampakan bulan di Hawtat Sudair.\r\nDilansir Arab News, Senin (11/3/2024), penampakan yang dilakukan para astronom dari Departemen Observatorium Astronomi Universitas Majmaah di Riyadh ini menandai dimulainya bulan suci bagi umat muslim.\r\n\r\nPeristiwa penting ini dipimpin oleh astronom terkemuka Saudi, Direktur Observatorium Astronomi, Abdullah Al-Khudairi, di Sudair. Mahkamah Agung Saudi mengumumkan bahwa Senin, 11 Maret, akan menjadi hari pertama Ramadan.\r\n\r\nSelain Arab Saudi, Qatar dan UEA juga telah mengonfirmasi bahwa Ramadan akan dimulai pada hari Senin 11 Maret. Sementara itu, Oman, Pakistan, Australia, Malaysia, Brunei, dan Iran pada 12 Maret.\r\n\r\nPenentuan tanggal mulai bergantung pada perhitungan bulan dan penampakan fisik bulan baru, sebuah praktik yang berakar pada tradisi Islam.\r\n\r\n\"Perhitungan dan teknologi melengkapi proses penampakan. Saya katakan bahwa perhitungan astronomi dan pengamatan dengan mata telanjang, seperti mata manusia, keduanya saling membutuhkan,\" kata Al-Khudairi.\r\n\r\nKe depan, Universitas Majmaah mengungkapkan rencana untuk meningkatkan fasilitasnya dan menambah timnya untuk lebih menyederhanakan proses penampakan bulan.\r\n\r\n\"Kami memiliki rencana strategis untuk memperluas fasilitas, peralatan, dan tenaga kerja kami di sini (Hawtat Sudair),\" kata Wakil Direktur Penelitian Pascasarjana dan Ilmiah di Universitas Majmaah.\r\n\r\n\"Kami ingin membangun gedung besar di sini. Ini akan menjadi pusat Majmaah untuk melihat bulan,\" imbuhnya.\r\n', 'berita11.jpg', 'Udin Madani', '2024-03-11 07:07:58', NULL),
(3, 'ASAL USUL SUMATERA BARAT - SEJARAH MINANG KABAU', 'Sumatera Barat adalah Propinsi yang mempunyai sejarah panjang, dimana setiap sejarahnya mempunyai makna tersendiri bagi masyarakat Minangkabau.\r\n\r\nAsal usul Sumatera Barat. Siapa yang tidak mengenal suku Minang ?. Suku ini merupkan salah satu suku yang terkenal dengan cerita rakyatnya yang begitu melegenda diseluruh tanah air. Suku Minang berada di Sumatera Barat salah satu Propinsi yang terletak di sepanjang pesisir pulau Sumatera. Padang sebagai ibu kota Sumatera Barat dikenal dengan masakannya yang khas dan dominan bumbu asli dari rempah – rempah Indonesia.\r\n\r\nPropinsi dengan jumlah penduduk 4.864.909 jiwa ini memang dominan dihuni oleh masyarakat yang beretnis Minang, karena itu wajar saja jika Sumatera Barat dikenal lewat suku Minangkabau. Namun Propinsi yang begitu elok ini tentu memiliki sejarah tersendiri. Bagaimana asal - usul Sumatera Barat ?. Awal mulnya Minangkabau.\r\n\r\nSejarah bermula pada masa nkerajaan Adityawarman, yang merupakan tokoh penting Minangkabau. Seorang Raja yang tidak ingin disebut sebagai Raja, pernah memerintah di Pagaruyuang, daerah pusatkerajaan Minangkabau, selain itu beliau juga orang pertama yang memperkenalkan sistim kerajaan di Sumatera Barat.\r\n\r\nSejak Pemerintah Raja Adityawarman tepatnya pertengahan abad ke – 17, Propinsi ini lebih terbuka dengan dunia luar khususnya Aceh. Karena hubungan dengan Aceh yang semakin intensif melalui kegiatan ekonomi masyarakat, akhirnya mulai berkembang nilai baru yang menjadi landasan sosial budaya masyarakat Sumatera Barat.', 'minang.jpeg', 'Bujang Maimbau', '2024-04-25 07:42:47', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_sejarawan`
--

CREATE TABLE `tb_sejarawan` (
  `id_sejarawan` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL DEFAULT '''"No Image"''',
  `tgl_lahir` varchar(255) NOT NULL,
  `asal` varchar(255) NOT NULL,
  `jenis_kelamin` text NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_sejarawan`
--

INSERT INTO `tb_sejarawan` (`id_sejarawan`, `nama`, `foto`, `tgl_lahir`, `asal`, `jenis_kelamin`, `deskripsi`) VALUES
(5, 'Muhammad Hatta', 'hatta.png', '12 Agustus 1902', 'Sumatera Barat', 'Pria', 'Mohammad Hatta lahir di Bukittinggi, Sumatra Barat dengan nama Mohammad Athar pada 12 Agustus 1902. Beliau wafat di Jakarta pada 14 Maret 1980.\r\n\r\nAyah dari Mohammad Hatta adalah Haji Muhammad Jamil, seorang keturunan ulama Tariqat Naqsyabandiyah di Payakumbuh. Datuk (kakek) dari Mohammad Hatta, Syaikh Abdurrahman adalah seorang ulama besar di surau Batuhampar, sekitar 9 kilometer dari Payakumbuh. Hatta memanggil kakeknya, Ayah Gaek. Ketika Hatta berumur 8 bulan, Muhammad Jamil wafat. Hatta memiliki seorang kakak perempuan, Rafi’ah yang usianya terpaut sekitar dua tahun (Hatta 2014a: 18-19).\r\n\r\nSiti Saleha, ibu dari Hatta berasal dari kalangan pedagang. Ayah dari Siti Saleha adalah Ilyas Bagindo Marah, salah seorang pedagang kaya di Bukittinggi (Abbas 2010:24). Pak Gaek adalah panggilan Hatta untuk Ilyas gelar Bagindo Marah. Setelah ayah dari Mohammad Hatta wafat, ibunya menikah lagi dengan Mas Agus Haji Ning, seorang saudagar asal Palembang. Hatta memiliki empat orang adik yang semuanya perempuan (Noer 1991: 16-17; Abbas 2010: 25; Noer 2012: 3-5).\r\n\r\nKetika Hatta berusia lima tahun, Pak Gaek akan memasukkan ke sekolah rakyat di Bukittinggi. Namun, Hatta belum dapat diterima karena usianya belum enam tahun dan ia belum dapat menjangkau telinga kirinya dengan tangan kanan di atas kepalanya. Pak Gaek kemudian memasukkan Hatta ke sekolah milik temannya, Ledeboer, seorang mantan tentara yang memiliki sekolah Belanda swasta. Pada pagi hari Hatta bersekolah dan sesudah magrib belajar mengaji di surau Inyik Djambek. Selain itu Hatta juga mengikuti pelajaran tambahan bahasa Inggris tiga kali seminggu (Penders 1981: 19, 24; Hatta 2014a: 30, 41).'),
(10, 'Haji Agus Salim', 'HajiAgusSalim.png', '8 Oktober 1884', 'Agam', 'Pria', 'Agus Salim lahir dari pasangan Soetan Salim gelar Soetan Mohamad Salim dan Siti Zainab. Jabatan terakhir ayahnya adalah Jaksa Kepala di Pengadilan Tinggi Riau.[3]  Pendidikan dasar ditempuh di Europeesche Lagere School (ELS), sekolah khusus bagi anak-anak Eropa, kemudian dilanjutkan ke Hoogere Burgerschool (HBS) Koning Willem III (Kawedrie) di Batavia. Ketika lulus, ia berhasil menjadi alumnus terbaik di HBS se-Hindia Belanda.  Setelah lulus, Salim bekerja sebagai penerjemah dan pembantu notaris pada sebuah kongsi pertambangan di Indragiri. Pada tahun 1906, Salim berangkat ke Jeddah, Arab Saudi untuk bekerja di Duta besar Belanda di sana. Pada periode inilah Salim berguru pada Syaikh Ahmad Khatib, yang masih merupakan pamannya.  Pada tahun 1912-1915, Salim membuka sekolah dasar berbahasa Belanda, Hollandsch-Inlandsche School (HIS). Kemudian pada tahun 1915 ia terjun ke dunia jurnalistik di Harian Neratja sebagai Wakil Redaktur. Setelah itu diangkat menjadi Ketua Redaksi. Agus Salim menikah dengan Zaenatun Nahar Almatsier dan dikaruniai 10 orang anak.[4] Kegiatannya dalam bidang jurnalistik terus berlangsung hingga akhirnya menjadi Pemimpin Harian Hindia Baroe di Jakarta. Kemudian mendirikan Surat kabar Fadjar Asia. Dan selanjutnya sebagai Redaktur Harian Moestika di Kota Yogyakarta dan membuka kantor Advies en Informatie Bureau Penerangan Oemoem (AIPO). Bersamaan dengan itu ia juga terjun dalam dunia politik sebagai pemimpin Sarekat Islam.,'),
(21, 'asdasd', '663868576cb44.jpg', 'sadas', '', 'sadas', 'asdsad');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `fullname` varchar(150) NOT NULL,
  `tanggal_lahir` varchar(255) NOT NULL,
  `jenis_kelamin` varchar(255) NOT NULL,
  `no_hp` varchar(13) NOT NULL,
  `email` varchar(100) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `fullname`, `tanggal_lahir`, `jenis_kelamin`, `no_hp`, `email`, `alamat`, `password`, `created`, `updated`) VALUES
(7, 'Astrid', '$2132131', '', '', '1', 'asdasdasdasd', '1', '2024-05-06 22:03:34', NULL),
(8, 'Astrid', '$asdas', 'perempuan', '213131', 'asdasdas', 'sadasd', 'c4ca4238a0b923820dcc509a6f75849b', '2024-05-06 22:45:28', NULL),
(9, 'Astrid', '$dasda', 'dasd', 'asdasd', 'asdasd', 'adsas', 'c4ca4238a0b923820dcc509a6f75849b', '2024-05-06 23:16:19', NULL),
(10, '2', '$2', '2', '2', '2@gmail.com', '2', 'c4ca4238a0b923820dcc509a6f75849b', '2024-05-06 23:20:15', NULL),
(11, '3', '$3', '3', '3', '3', '3', 'c4ca4238a0b923820dcc509a6f75849b', '2024-05-06 23:25:41', NULL),
(12, '3', '$3', '3', '3', '3', '3', 'c4ca4238a0b923820dcc509a6f75849b', '2024-05-06 23:37:36', NULL),
(13, '4', '', '', '', '4', '', 'a87ff679a2f3e71d9181a67b7542122c', '2024-05-06 23:47:07', NULL),
(14, 'Astrid', '$asdasdsa', 'asdasd', 'sadasd', '6', 'asdsad', '6', '2024-05-06 23:47:20', NULL),
(15, 'astrid', '$sad', 'asdas', 'sdada', '123', 'sadas', '123', '2024-05-06 23:57:56', NULL),
(16, 'Loki', '$123', 'sadas', '23213', '8', '3213', 'c9f0f895fb98ab9159f51fd0297e236d', '2024-05-07 00:01:11', NULL),
(17, 'Kiko', '$20 Juli 2001', 'Pria', '0921321', '10', 'Padang', 'd3d9446802a44259755d38e6d163e820', '2024-05-07 00:17:05', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_berita`
--
ALTER TABLE `tb_berita`
  ADD PRIMARY KEY (`id_berita`);

--
-- Indexes for table `tb_sejarawan`
--
ALTER TABLE `tb_sejarawan`
  ADD PRIMARY KEY (`id_sejarawan`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_berita`
--
ALTER TABLE `tb_berita`
  MODIFY `id_berita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_sejarawan`
--
ALTER TABLE `tb_sejarawan`
  MODIFY `id_sejarawan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
