<?php

header("Access-Control-Allow-Origin: *");
include 'koneksi.php';

if($_SERVER['REQUEST_METHOD'] == "POST") {
    $response = array();
    
    $id = $_POST['id_user'];
    $fullname = $_POST['fullname'];
    $alamat = $_POST['alamat'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $no_hp = $_POST['no_hp']; 
    $email = $_POST['email']; 
    $jenis_kelamin = $_POST['jenis_kelamin']; 
    $password = md5($_POST['password']); 

    $sql = "UPDATE tb_user SET fullname = '$fullname', no_hp = '$no_hp', email = '$email', jenis_kelamin = '$jenis_kelamin', alamat = '$alamat', tanggal_lahir = '$$tanggal_lahir', password = '$password' WHERE id_user = $id";
    $isSuccess = $koneksi->query($sql);

    if ($isSuccess) {
        $cek = "SELECT * FROM tb_user WHERE id_user = $id";
        $result = mysqli_fetch_array(mysqli_query($koneksi, $cek));
        $response['is_success'] = true;
        $response['value'] = 1;
        $response['message'] = "User Berhasil di Edit";
        $response['fullname'] = $result['fullname'];
        $response['no_hp'] = $result['no_hp'];
        $response['alamat'] = $result['alamat'];
        $response['tanggal_lahir'] = $result['tanggal_lahir'];
        $response['jenis_kelamin'] = $result['jenis_kelamin']; 
        $response['email'] = $result['email']; 
        $response['password'] = $result['password']; 
        $response['id_user'] = $result['id_user'];
    } else {
        $response['is_success'] = false;
        $response['value'] = 0;
        $response['message'] = "Gagal Edit User";
    }

    echo json_encode($response);
}

?>
