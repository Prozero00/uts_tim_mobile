<?php

header("Access-Control-Allow-Origin: *");

include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Pastikan bahwa semua parameter yang diperlukan tersedia
    if (isset($_POST['nama']) && isset($_POST['foto']) && isset($_POST['tgl_lahir']) && isset($_POST['asal']) && isset($_POST['jenis_kelamin']) && isset($_POST['deskripsi'])) {
        $nama = $_POST['nama'];
        $foto = $_POST['foto'];
        $tanggal_lahir = $_POST['tgl_lahir'];
        $asal = $_POST['asal'];
        $jenis_kelamin = $_POST['jenis_kelamin'];
        $deskripsi = $_POST['deskripsi'];

        // Decode base64 string menjadi gambar
        $foto = base64_decode($foto);

        // Tentukan lokasi penyimpanan gambar
        $upload_path = "../uts_tim_mobile/image/"; // Ubah sesuai dengan lokasi penyimpanan Anda

        // Buat nama file unik
        $file_name = uniqid() . '.jpg'; // Ubah ekstensi sesuai dengan format gambar yang Anda terima

        // Simpan gambar di server
        if (file_put_contents($upload_path . $file_name, $foto)) {
            // Gambar berhasil disimpan, lanjutkan dengan penyimpanan data ke database
            $sql = "INSERT INTO tb_sejarawan (nama, foto, tgl_lahir, asal, jenis_kelamin, deskripsi) VALUES ('$nama','$file_name', '$tanggal_lahir', '$asal', '$jenis_kelamin', '$deskripsi')";
            if ($koneksi->query($sql) === TRUE) {
                $response['isSuccess'] = true;
                $response['message'] = "Berhasil menambahkan data sejarawan";
            } else {
                $response['isSuccess'] = false;
                $response['message'] = "Gagal menambahkan data sejarawan: " . $koneksi->error;
            }
        } else {
            $response['isSuccess'] = false;
            $response['message'] = "Gagal menyimpan gambar di server";
        }
    } else {
        $response['isSuccess'] = false;
        $response['message'] = "Parameter tidak lengkap";
    }
} else {
    $response['isSuccess'] = false;
    $response['message'] = "Metode yang diperbolehkan hanya POST";
}

echo json_encode($response);
?>