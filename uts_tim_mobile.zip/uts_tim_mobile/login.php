<?php

header("Access-Control-Allow-Origin: header");
header("Access-Control-Allow-Origin: *");

include 'koneksi.php';

if($_SERVER['REQUEST_METHOD'] == "POST") {
    $response = array();
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $cek = "SELECT * FROM tb_user WHERE email = '$email' AND password = '$password'";
    $result = mysqli_fetch_array(mysqli_query($koneksi, $cek));

    if(isset($result)){
        $response['value'] = 1;
        $response['message'] = "berhasil login";
        $response['fullname'] = $result['fullname'];
        $response['tanggal_lahir'] = $result['tanggal_lahir'];
        $response['jenis_kelamin'] = $result['jenis_kelamin'];
        $response['no_hp'] = $result['no_hp'];
        $response['email'] = $result['email'];
        $response['alamat'] = $result['alamat'];
        $response['id_user'] = $result['id_user'];
        echo json_encode($response);
    } else {
        $response['value'] = 0;
        $response['message'] = "Gagal login";
        echo json_encode($response);
    }
}

?>